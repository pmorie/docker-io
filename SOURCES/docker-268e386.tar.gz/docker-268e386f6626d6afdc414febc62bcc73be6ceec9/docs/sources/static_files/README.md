Static files dir
================

Files you put in /sources/static_files/ will be copied to the web visible /_static/

Be careful not to override pre-existing static files from the template.

Generally, layout related files should go in the /theme directory.

If you want to add images to your particular documentation page. Just put them next to
your .rst source file and reference them relatively.