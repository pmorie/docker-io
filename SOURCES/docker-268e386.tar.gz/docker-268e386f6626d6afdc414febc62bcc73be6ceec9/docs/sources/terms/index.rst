:title: Glossary
:description: Definitions of terms used in Docker documentation
:keywords: concepts, documentation, docker, containers



Glossary
========

Definitions of terms used in Docker documentation.

Contents:

.. toctree::
   :maxdepth: 1

   filesystem
   layer
   image
   container


