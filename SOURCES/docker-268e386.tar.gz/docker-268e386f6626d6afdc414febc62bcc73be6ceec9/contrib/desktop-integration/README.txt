Desktop Integration
===================

The ./contrib/desktop-integration contains examples of typical dockerized
desktop applications.

Examples
========

* Data container: ./data/Dockerfile creates a data image sharing /data volume
* Firefox: ./firefox/Dockerfile shows a way to dockerize a common multimedia application
