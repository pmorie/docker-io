# Dockerfile.tmLanguage

Pretty basic Dockerfile.tmLanguage for Sublime Text syntax highlighting.

PR's with syntax updates, suggestions etc. are all very much appreciated!

I'll get to making this installable via Package Control soon!

enjoy.
