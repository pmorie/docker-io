Buildbot configuration and setup files
